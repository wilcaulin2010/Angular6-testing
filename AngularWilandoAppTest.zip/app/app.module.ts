import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginPageComponent } from './WRC.VIEWS/login-page/login-page.component';
import { MenuPageComponent } from './WRC.VIEWS/menu-page/menu-page.component';
import { DashboardPageComponent } from './WRC.VIEWS/dashboard-page/dashboard-page.component';
import { AdminPageComponent } from './WRC.VIEWS/admin-page/admin-page.component';
import { TenantPageComponent } from './WRC.VIEWS/tenant-page/tenant-page.component';
import { LessorPageComponent } from './WRC.VIEWS/lessor-page/lessor-page.component';
import { ReportsPageComponent } from './WRC.VIEWS/reports-page/reports-page.component';
import { EmailPageComponent } from './WRC.VIEWS/email-page/email-page.component';
import { UserDetailComponent } from './user-detail/user-detail.component';




@NgModule({
  declarations: [
    AppComponent,
    LoginPageComponent,
    MenuPageComponent,
    DashboardPageComponent,
    AdminPageComponent,
    TenantPageComponent,
    LessorPageComponent,
    ReportsPageComponent,
    EmailPageComponent,
    UserDetailComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    ReactiveFormsModule,
    BrowserAnimationsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }

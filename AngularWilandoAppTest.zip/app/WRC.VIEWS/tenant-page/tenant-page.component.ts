import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tenant-page',
  templateUrl: './tenant-page.component.html',
  styleUrls: ['./tenant-page.component.scss']
})
export class TenantPageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

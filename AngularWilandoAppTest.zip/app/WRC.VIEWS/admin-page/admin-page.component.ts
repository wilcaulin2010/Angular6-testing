import { Component, OnInit } from '@angular/core';
import { CustomerService } from '../../WRC.STE/customer.service';

@Component({
  selector: 'app-admin-page',
  templateUrl: './admin-page.component.html',
  styleUrls: ['./admin-page.component.scss']
})

export class AdminPageComponent implements OnInit {
  customers$;

  constructor(private customer: CustomerService) {

  }

    ngOnInit() {
    this.customer.getAll().subscribe(customer => this.customers$ = customer);
  }

}




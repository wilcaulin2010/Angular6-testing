import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-email-page',
  templateUrl: './email-page.component.html',
  styleUrls: ['./email-page.component.scss']
})
export class EmailPageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

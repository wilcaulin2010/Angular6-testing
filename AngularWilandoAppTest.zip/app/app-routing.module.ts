import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { LoginPageComponent } from './WRC.VIEWS/login-page/login-page.component';
import { MenuPageComponent } from './WRC.VIEWS/menu-page/menu-page.component';
import { DashboardPageComponent } from './WRC.VIEWS/dashboard-page/dashboard-page.component';
import { AdminPageComponent } from './WRC.VIEWS/admin-page/admin-page.component';
import { TenantPageComponent } from './WRC.VIEWS/tenant-page/tenant-page.component';
import { LessorPageComponent } from './WRC.VIEWS/lessor-page/lessor-page.component';
import { ReportsPageComponent } from './WRC.VIEWS/reports-page/reports-page.component';
import { EmailPageComponent } from './WRC.VIEWS/email-page/email-page.component';


const routes: Routes = [
  {
    path: '',
    component: DashboardPageComponent
  },
  {
    path: 'admin-page',
    component: AdminPageComponent
  },
  {
    path: 'lessor-page',
    component: LessorPageComponent
  },
    {
    path: 'tenant-page',
    component: TenantPageComponent
  },
      {
    path: 'reports-page',
    component: ReportsPageComponent
  },
      {
    path: 'email-page',
    component: EmailPageComponent
  },
  { path: '', redirectTo: 'WRC.VIEWS', pathMatch: 'full' },
  { path: '**', redirectTo: 'WRC.VIEWS' },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

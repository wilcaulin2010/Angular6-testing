import { TestBed } from '@angular/core/testing';

import { WebAPICustomerService } from './web-apicustomer.service';

describe('WebAPICustomerService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: WebAPICustomerService = TestBed.get(WebAPICustomerService);
    expect(service).toBeTruthy();
  });
});
